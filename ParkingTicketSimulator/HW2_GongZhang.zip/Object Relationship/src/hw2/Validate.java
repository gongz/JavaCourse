package hw2;

public interface Validate {
	//might be used to check score, age, date, etc.
	public boolean isValid(int value);
}
