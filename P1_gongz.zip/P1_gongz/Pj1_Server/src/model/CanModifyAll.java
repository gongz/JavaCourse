package model;

import system.kbbSystem;

public interface CanModifyAll {
	public abstract void modifyAll(kbbSystem sys);
}
