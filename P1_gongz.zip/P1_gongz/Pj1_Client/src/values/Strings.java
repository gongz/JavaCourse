package values;

public class Strings {
	public static final String FILEIN = "Enter file name of the car model";
	public static final String RECEIVING ="Receiving model";
	public static final String MODELIN = "Input the name and model of the car you want to edit, e.g.\"BMW Wagon ZTW\"";
	public static final String OPTIONIN = "Enter an Option Set name, option name and price to edit option name and price, e.g.\"COLOR, green, 100\"";
	public static final String CONT = "Press Enter to continue";
	public static final String SHOW = "Showing";
}
