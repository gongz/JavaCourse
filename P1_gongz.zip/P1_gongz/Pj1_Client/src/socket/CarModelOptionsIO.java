package socket;

import java.io.IOException;

public class CarModelOptionsIO {

	public static void main(String[] args) throws IOException {
		Client.createSocket();
	}

}
