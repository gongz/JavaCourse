package exceptionHandler;

public class illgalInputFormat extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3843233685583517988L;
	
}
