package exceptionHandler;

public class illegalName extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3026001941506153138L;

}
