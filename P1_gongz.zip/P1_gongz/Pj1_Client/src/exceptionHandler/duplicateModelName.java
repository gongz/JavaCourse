package exceptionHandler;


public class duplicateModelName extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8635758031321389685L;

}
