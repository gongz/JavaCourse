package exceptionHandler;

public class illgalPrice extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2511333396668228155L;

}
