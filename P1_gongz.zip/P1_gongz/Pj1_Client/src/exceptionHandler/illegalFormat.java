package exceptionHandler;


public class illegalFormat extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8532195523189458710L;

}
