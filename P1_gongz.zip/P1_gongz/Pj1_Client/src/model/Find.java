package model;

public interface Find {
	public abstract Object find(Object o);
}
