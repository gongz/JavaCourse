package model;

public interface CanRead {
	public abstract String read(Automobile auto);
}
