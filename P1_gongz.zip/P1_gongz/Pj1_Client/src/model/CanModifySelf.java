package model;

public interface CanModifySelf {
	public abstract void modifySelf(Automobile auto);
}
